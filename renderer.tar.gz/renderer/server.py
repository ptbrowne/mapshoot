import os
import sh

from flask import Flask
from flask import send_file

app = Flask(__name__)

def get_bounds_zoom(render_string):
    return render_string.split(', ')


def get_rendered_path(bounds, zoom):
    return 'rendered/%s-%s.png' % (bounds, zoom)

@app.route('/render/<render_string>')
def render(render_string):
    if not os.path.exists(get_rendered_path(*get_bounds_zoom(render_string))):
        command = sh.Command('./render_image.sh')
        command(*render_string.split(' '))
    return 'rendered', 200    

@app.route('/rendered/<render_string>')
def serve_rendered(render_string):
    mimetypes = {
        ".css": "text/css",
        ".html": "text/html",
        ".js": "application/javascript",
        ".png": "image/png"
    }
    bounds, zoom = get_bounds_zoom(render_string)
    path = get_rendered_path(bounds, zoom)
    complete_path = os.path.join('.', path)
    ext = os.path.splitext(path)[1]
    mimetype = mimetypes.get(ext, "text/html")
    return send_file(complete_path, mimetype=mimetype)

app.run(host='0.0.0.0', debug=True)
