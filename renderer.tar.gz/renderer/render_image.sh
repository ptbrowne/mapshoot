#!/bin/bash

STYLESHEET=/usr/local/share/maps/style/OSMBright/OSMBright.xml
PPI=300

counter=0

line=$@
ZOOM=$(echo $line | cut -d',' -f2 | tr -d ' ')
BOUNDS=$(echo $line | cut -d',' -f1)
IMAGE_NAME=rendered/$BOUNDS-$ZOOM.png
  
# render map with mapnik
nik4.py --norotate --ppi $PPI -b $BOUNDS -z $ZOOM $STYLESHEET "$IMAGE_NAME"
  
# add legend with imagemagick
composite -geometry 200x200+50+50 sonic.tiff "$IMAGE_NAME" "$IMAGE_NAME"

# increment loop counter
counter=$((counter+1))
echo "Generated $IMAGE_NAME. Bounds $BOUNDS"
