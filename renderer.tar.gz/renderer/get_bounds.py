import requests
import json
import sys

def main():
    geojsonio_url = sys.argv[1]
    geojsonio_id = geojsonio_url[37:69]

    geojson_url = 'https://gist.github.com/anonymous/%s/raw/' % geojsonio_id
    geojson = json.loads(requests.get(geojson_url).text)
    for f in geojson['features']:
         g = f['geometry']
         zoom = f['properties'].get('zoom', 17)
         coords = g['coordinates'][0]
         if g['type'] == 'Polygon' and len(coords) == 5:
             print '%s %s' % tuple(coords[0]),
             print '%s %s,' % tuple(coords[2]),
             print zoom
    
if __name__ == '__main__':
    main()
